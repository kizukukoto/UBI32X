// Windows/FileMapping.cpp

#include "StdAfx.h"

#include "Windows/FileMapping.h"

namespace NWindows {
namespace NFile {
namespace NMapping {




}}}