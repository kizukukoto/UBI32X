// WorkDir.h

#ifndef __WORKDIR_H
#define __WORKDIR_H

#include "ZipRegistry.h"

UString GetWorkDir(const NWorkDir::CInfo &workDirInfo, const UString &path);

#endif
